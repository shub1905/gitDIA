%Programmer: Chris Tralie

function [ seam, energy ] = find_vertical_seam( energy_img )
PixelDim = size(energy_img);
for row = 2:PixelDim(1)
   for col = 1:PixelDim(2)
      %Look up at the above row and find the min path weight 
      %(taking care not to overstep the boundaries of the image)
      left = max(col - 1, 1);
      right = min(col+1, PixelDim(2));
      minpath = min( energy_img(row - 1, left:right) );
      energy_img(row, col) = energy_img(row, col) + minpath;
   end
end

%Find the minimum energy path at the bottom
[energy, Index] = min(energy_img(PixelDim(1), 1:PixelDim(2)));

%Preallocate space to hold the seam path
seam = ones(PixelDim(1), 1); 

%Backtrack through the energy matrix (from bottom to top) 
%to determine the path of the minimum energy seam
for row = PixelDim(1)-1:-1:1
    j = Index(1);%The column of the location of the min energy seam
    %from the last row
    seam(row + 1) = j;
    left = max(j-1, 1);
    right = min(j+1, PixelDim(2));
    [C, Index] = min( energy_img(row, left:right) );
    Index = Index + left - 1;
end
seam(1) = Index(1);


end