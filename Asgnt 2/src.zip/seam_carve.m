%Programmer: Chris Tralie

%By default, no "remove" regions are specified
function [ image ] = seam_carve( filename, target_rows, target_columns )
    image = seam_carve_extended(filename, 'null', target_rows, target_columns);
end