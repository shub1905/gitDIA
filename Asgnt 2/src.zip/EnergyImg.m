%Programmer: Chris Tralie

function [energy_img ] = EnergyImg( im, remove )
%Find the x and y components of the gradient Fx and Fy of the image
%smoothed with a gaussian; do so with with a separable gaussian

sigma = 1;
width = round(3*sigma);
t = -width: 1: width;
gaussf = exp(-t.*t ./ (2*sigma^2));%Unidirectional gaussian kernel
xgaussf = -t.*exp(-t.*t ./ (2*sigma^2)); %Unidirectional gradient of gaussian kernel

gaussf = gaussf / sum(gaussf);%Normalize the gaussian

%Now find a proper normalization scale for the gaussian gradient, such 
%that a region with slope 1 will come out to have slope 1
ramp = 1:width*2 + 1;
xgaussf = xgaussf / abs((ramp * xgaussf'));

Fx = conv2(gaussf, xgaussf, im, 'same');
Fy = conv2(xgaussf, gaussf, im, 'same');

energy_img = abs(Fx) + abs(Fy);
energy_img = energy_img / max(max(energy_img));%Normalize

energy_img = min(energy_img, remove);

end