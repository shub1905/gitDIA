%Programmer: Chris Tralie

function [ seam, energy ] = find_horizontal_seam( energy_img )
%Try to reuse code from find_vertical seam (send it the transpose)
[seam, energy] = find_vertical_seam(energy_img');
end

