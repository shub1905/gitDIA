%Programmer: Chris Tralie

function [ imcolor ] = markSeam( imcolor, seam, type )
    if strcmp(type, 'HORIZONTAL') 
        %Horizontal seam
        for i = 1:size(seam)
            imcolor(seam(i), i, 1) = 255;%Mark the seam in red
            imcolor(seam(i), i, 2) = 0;%Mark the seam in red
            imcolor(seam(i), i, 3) = 0;%Mark the seam in red
        end
    else
        %Vertical seam
        for i = 1:size(seam)
            imcolor(i, seam(i), 1) = 255;
            imcolor(i, seam(i), 2) = 0;
            imcolor(i, seam(i), 3) = 0;
        end
    end
end

