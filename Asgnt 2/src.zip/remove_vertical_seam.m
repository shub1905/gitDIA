%Programmer: Chris Tralie

function [ imcolor, im, remove ] = remove_vertical_seam( imcolor, im, remove, seam )
PixelDim = size(im);

for i = 1:PixelDim(1)
    for j = seam(i):PixelDim(2)-1
       im(i, j) = im(i, j+1);
       remove(i, j) = remove(i, j+1);
       imcolor(i, j, 1) = imcolor(i, j+1, 1);
       imcolor(i, j, 2) = imcolor(i, j+1, 2);
       imcolor(i, j, 3) = imcolor(i, j+1, 3);
    end
end

%now delete the last column
im(:, PixelDim(2)) = [];
remove(:, PixelDim(2)) = [];
imcolor(:, PixelDim(2), :) = [];
end