%Programmer: Chris Tralie

%removefile specifies areas of the image that should be removed
function [ image ] = seam_carve_extended(filename, removefile, target_rows, target_columns)
imcolor = imread(filename);
gray = rgb2gray(imcolor);
im = double(gray) / 255;%Normalized grayscale image used for analysis
PixelDim = size(im);
if strcmp(removefile, 'null')
    remove = double(ones(PixelDim(1), PixelDim(2)));
else
    remove = double(rgb2gray(imread(removefile))) / 255;
end

markseam = 0;
%Do vertical seam trimming first
while PixelDim(2) > target_columns || PixelDim(1) > target_rows
    energy_img = EnergyImg(im, remove);
    energyvert = max(PixelDim(1), PixelDim(2));
    energyhoriz = energyvert;
    if PixelDim(2) > target_columns
        [vertseam, energyvert] = find_vertical_seam(energy_img);
    end
    if PixelDim(1) > target_rows
        [horizseam, energyhoriz] = find_horizontal_seam(energy_img);
    end
    
    %imwrite(energy_img, sprintf('%ix%ienergy.png', PixelDim(1), PixelDim(2)), 'png');
        
    if energyvert < energyhoriz
        [imcolor, im, remove] = remove_vertical_seam(imcolor, im, remove, vertseam);
        if markseam == 1
            image = markSeam(imcolor, vertseam, 'VERTICAL');
            imwrite(image, sprintf('%ix%ivertical.png', PixelDim(1), PixelDim(2)), 'png');
        end
    else
        [imcolor, im, remove] = remove_horizontal_seam(imcolor, im, remove, horizseam);
        if markseam == 1
            image = markSeam(imcolor, horizseam, 'HORIZONTAL');
            imwrite(image, sprintf('%ix%ihorizontal.png', PixelDim(1), PixelDim(2)), 'png');
        end
    end
    PixelDim = size(im)
end

image = imcolor;

end