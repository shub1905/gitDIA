%Programmer: Chris Tralie

function [ imcolor, im, remove ] = remove_horizontal_seam( imcolor, im, remove, seam )
PixelDim = size(im);

for j = 1:PixelDim(2)
    for i = seam(j):PixelDim(1)-1
       im(i, j) = im(i+1, j);
       remove(i, j) = remove(i+1, j);
       imcolor(i, j, 1) = imcolor(i+1, j, 1);
       imcolor(i, j, 2) = imcolor(i+1, j, 2);
       imcolor(i, j, 3) = imcolor(i+1, j, 3);
    end
end

%now delete the last row
im(PixelDim(1), :) = [];
remove(PixelDim(1), :) = [];
imcolor(PixelDim(1), :, :) = [];
end